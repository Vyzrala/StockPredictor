installation: 
	Double click *.exe 

example usage: 

	from StockPredictorLSTM import Predictor
	import pandas_datareader as pdr
	import datetime


	COMPANY_NAME = 'FB'
	START_DATE = '2017-01-01'
	END_DATE = '2018-05-02'
	SOURCE = 'yahoo'
	df = pdr.DataReader(COMPANY_NAME, SOURCE, START_DATE, END_DATE)
	df.reset_index(inplace=True)

	model = Predictor()
	model.create_model(df)
	model.display_info()