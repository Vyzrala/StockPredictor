windows cmd installation:

tar xzvf StockPredictorLSTM-Vyzrala-0.1.1.tar.gz
cd StockPredictorLSTM
python setup.py install
